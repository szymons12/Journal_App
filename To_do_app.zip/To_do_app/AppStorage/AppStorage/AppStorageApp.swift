//
//  AppStorageApp.swift
//  AppStorage
//
//  Created by szymon on 12/02/2024.
//

import SwiftUI

@main
struct AppStorageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
