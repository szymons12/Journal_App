//
//  ContentView.swift
//  AppStorage
//
//  Created by szymon on 12/02/2024.
//

import SwiftUI
import CoreData

class CoreDataViewModel: ObservableObject {
    let container: NSPersistentContainer
    @Published var savedEntities: [FruitEntity] = []

    init() {
        container = NSPersistentContainer(name: "FruitsContainer")
        container.loadPersistentStores { (description, error) in
            if let error = error {
                print("ERROR LOADING CORE DATA. \(error)")
            }
        }
        fetchFruits()
    }

    func fetchFruits() {
        let request = NSFetchRequest<FruitEntity>(entityName: "FruitEntity")

        do {
            savedEntities = try container.viewContext.fetch(request)
        } catch let error {
            print("Error fetching. \(error)")
        }
    }

    func addFruit(text: String) {
        let newFruit = FruitEntity(context: container.viewContext)
        newFruit.name = text
        saveData()
    }

    func deleteFruit(indexSet: IndexSet) {
        guard let index = indexSet.first else { return }
        let entity = savedEntities[index]
        container.viewContext.delete(entity)
        saveData()
    }

    func saveData() {
        do {
            try container.viewContext.save()
            fetchFruits()
        } catch let error {
            print("Error saving \(error)")
        }
    }
}

struct ContentView: View {
    @StateObject var vm = CoreDataViewModel()
    @State var textFieldText: String = ""

    struct ListItemStyle: ViewModifier {
        func body(content: Content) -> some View {
            content
                .font(.custom("Inter-Thin", size: 24))
                .foregroundColor(.blue)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 20)
        }
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Add fruit", text: $textFieldText)

                Button(action: {
                    guard !textFieldText.isEmpty else { return }
                    vm.addFruit(text: textFieldText)
                    textFieldText = ""
                }, label: {
                    Text("Save")
                })
                .padding(.horizontal)

                List {
                    ForEach(vm.savedEntities) { entity in
                        HStack {
                            Text(entity.name ?? "No name")
                                .modifier(ListItemStyle())
                        }
                        .listRowBackground(Color.green) // Dostosuj kolor tła dla każdego wiersza
                    }
                    .onDelete(perform: vm.deleteFruit)
                }
            }
            .navigationTitle("Fruits")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
