//
//  Budget.swift
//  To_do_appp
//
//  Created by szymon on 23/01/2024.
//

import SwiftUI

struct Budget: View {
    var body: some View {
        ZStack{
            Color("bdgBack").ignoresSafeArea()
            VStack(spacing: 0){
            AddBudget()
            TotBudget()
            }
        }
        
    }
}

struct Budget_Previews: PreviewProvider {
    static var previews: some View {
        Budget()
    }
}
