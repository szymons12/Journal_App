//
//  BudgetSheet.swift
//  To_do_appp
//
//  Created by szymon on 12/02/2024.
//

import SwiftUI

struct BudgetSheet: View {
    @State var name: String
    @State var cost: Int
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct BudgetSheet_Previews: PreviewProvider {
    static var previews: some View {
        BudgetSheet()
    }
}
