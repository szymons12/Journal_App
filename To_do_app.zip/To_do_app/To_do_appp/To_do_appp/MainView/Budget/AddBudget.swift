//
//  AddBudget.swift
//  To_do_appp
//
//  Created by szymon on 30/01/2024.
//

import SwiftUI

struct AddBudget: View {
    var body: some View {
        ZStack{
                Rectangle()
                .frame(width: 390, height: 320)
                .foregroundColor(Color("bdgBack"))
                .overlay(
                VStack{
                HStack{
                VStack(alignment: .leading) {
                               Text("Budget")
                                   .foregroundColor(Color.white)
                                   .font(.custom("Inter-Thin", size: 64))
                               
                               Text("for")
                                   .foregroundColor(Color.white)
                                   .font(.custom("Inter-Thin", size: 64))
                               
                               Text("today")
                                   .foregroundColor(Color.white)
                                   .font(.custom("Inter-Thin", size: 64))
                    }
                    Spacer()
                }
                    
                    Text("230$")
                    .foregroundColor(Color.white)
                    .font(.custom("Inter-ExtraBold", size: 48))
                    .frame(maxWidth: .infinity)
                    .padding(.bottom)
                   
                    
                    
                
                    }
                ) // Overlay
                        
        }   // ZStack
    }
}

struct AddBudget_Previews: PreviewProvider {
    static var previews: some View {
        AddBudget()
    }
}
