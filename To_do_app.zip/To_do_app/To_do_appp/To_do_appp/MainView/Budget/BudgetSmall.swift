//
//  BudgetSmall.swift
//  To_do_appp
//
//  Created by szymon on 30/01/2024.
//

import SwiftUI

struct BudgetSmall: View {
    
    @StateObject var vm = CoreDataViewModel()
    
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .stroke(.black)
            .frame(width: 139, height: 165)
            .foregroundColor(.white)
            .overlay(
                VStack{
                    Text("230$")
                        .font(.custom("Inter-Black", size: 32))
                        .frame(width: 110, height: 10)
                        .padding()
                            
                    ScrollView{
                        VStack(alignment: .leading){
                            ForEach(vm.savedEntities) { entity in
                                HStack() {
                                    Text(entity.name ?? "no name")
                                        .font(.custom("Inter-Thin", size: 15))
                                        .foregroundColor(.black)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(.leading, 2)

                                    Text("\(entity.cost)$")
                                        .font(.custom("Inter-Thin", size: 20))
                                        .frame(width: 40, alignment: .trailing)
                                        .foregroundColor(.black)
                                        .padding(.trailing, 2)
                                       
                                }//HStack
                            }//Entity
                        }//VStack
                    } //ScrollView
                    Spacer()
                }
            )
    }
}

struct BudgetSmall_Previews: PreviewProvider {
    static var previews: some View {
        BudgetSmall()
    }
}
