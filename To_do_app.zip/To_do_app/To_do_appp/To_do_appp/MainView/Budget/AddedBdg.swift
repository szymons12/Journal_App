//
//  AddedBdg.swift
//  To_do_appp
//
//  Created by szymon on 21/02/2024.
//

import SwiftUI

struct AddedBdg: View {

    var body: some View {
        Text("S")
        
    }
}

struct AddedBdg_Previews: PreviewProvider {
    static var previews: some View {
        AddedBdg()
    }
}
