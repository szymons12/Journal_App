//
//  TotBudget.swift
//  To_do_appp
//
//  Created by szymon on 30/01/2024.
//

import SwiftUI

struct TotBudget: View {
    @State var total: Int = 0
    @State var name: String = ""
    @State var num: String = ""
    @StateObject var vm = CoreDataViewModel()

    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 390, height: 474)
                .foregroundColor(Color.white)
                .overlay(
                    VStack {
                        VStack() {
                            HStack {
                                Text("Expense")
                                    .font(.custom("Inter-Light", size: 32))
                                    .padding()
                                Spacer()
                                Text("price:")
                                    .font(.custom("Inter-Regular", size: 32))
                                    .padding()
                            }// HStack
                           
                                VStack(alignment: .leading) {
                                    List {
                                        ForEach(vm.savedEntities) { entity in
                                            HStack {
                                                Text(entity.name ?? "no name")
                                                    .font(.custom("Inter-Thin", size: 32))
                                                    .foregroundColor(.black)
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .padding(.leading, 20)

                                                Text("\(entity.cost)$")
                                                    .font(.custom("Inter-Thin", size: 32))
                                                    .foregroundColor(.black)
                                                    .padding(.trailing, 40)
                                            }//HStack
                                            .listRowSeparator(.hidden)
                                        }//ForEach
                                        .onDelete(perform: vm.deleteTask)
                                       
                                    }//List
                                    .listStyle(PlainListStyle())
                                    .background(Color.white)
                                    
                                }//VStack
                           

                            .frame(width: 398, height: 190)

                            VStack {
                                HStack {
                                    TextField("Expense...", text: $name)
                                        .font(.custom("Inter-Thin", size: 32))
                                        .foregroundColor(.black)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .padding(.leading, 20)
                                    
                                    TextField("0$", text: $num)
                                        .font(.custom("Inter-Thin", size: 32))
                                        .foregroundColor(.black)
                                        .frame(width: 90, alignment: .trailing)
                                        .padding(.trailing, 40)
                                        
                                }//HStack

                                Button(action: {
                                    guard !name.isEmpty, let cost = Int16(num) else { return }
                                    vm.addTask(text: name, int: cost)
                                    name = ""
                                    total += Int(cost)
                                }, label: {
                                    Rectangle()
                                        .frame(width: 98, height: 58)
                                        .cornerRadius(20)
                                        .overlay(Text("Add")
                                            .font(.custom("Inter-Thin", size: 32))
                                            .foregroundColor(.white))
                                })//Button
                            } //VStack
                        }//Sec VStack

                        Spacer()

                        HStack {
                            Text("Total:")
                                .font(.custom("Inter-Thin", size: 64))
               
                            Text("\(total)$")
                                .font(.custom("Inter-ExtraBold", size: 48))
                                
                        }
                    } //Vstack1
                    .foregroundColor(Color.black)
                ) // overlay

        } .frame(width: 390, height: 468)
    }
}

struct TotBudget_Previews: PreviewProvider {
    static var previews: some View {
        TotBudget()
    }
}

