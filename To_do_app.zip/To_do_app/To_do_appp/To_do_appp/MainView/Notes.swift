//
//  Notes.swift
//  To_do_appp
//
//  Created by szymon on 23/01/2024.
//

import SwiftUI

struct Notes: View {
    @State var todayNote = ""
    var body: some View {

                    
                            
        TextEditor(text: $todayNote)
            .foregroundColor(.black)
            .font(.custom("Inter-Regular", size: 20))
            .padding()
            .frame(width: 363, height: 337)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                .strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [10]))
                    
            )
                
                                    
                                   
                                
                     
                      
                
        
            
    }
}

struct Notes_Previews: PreviewProvider {
    static var previews: some View {
        Notes()
    }
}
