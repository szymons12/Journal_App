//
//  MainView.swift
//  To_do_appp
//
//  Created by szymon on 10/03/2024.
//

import SwiftUI

struct MainView: View {
    let currentDate = Date()
    var body: some View {
        VStack{
            HStack(spacing: 70){
                Image(systemName: "line.3.horizontal")
                    .font(.custom("Inter-ExtraBold", size: 36))
                
                Text("\(formattedDate)")
                    .font(.custom("Inter-ExtraLight", size: 24))
                
                
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [10]))
                    .frame(width: 84, height: 66)
                    .foregroundColor(.black)
                    .overlay(
                        VStack(alignment: .leading){
                    Text("ACCO")
                    Text("UNT")
                        }.font(.custom("Inter-ExtraLight", size: 20))
                    )
            }
            VStack(spacing: 1){
            HStack{
                Text("DAILY")
                .foregroundColor(.black)
                .font(.custom("Inter-ExtraBold", size: 36))
               
                Image(systemName: "arrow.left")
                Spacer().frame(width: 10)
                Image(systemName: "arrow.right")
                Spacer().frame(width: 190)
            }
            
            
            HStack{
                DailyMainView()
                VStack(spacing: 5){
                    Text("Budget")
                    .foregroundColor(.black)
                    .font(.custom("Inter-ExtraLight", size: 36))
                    BudgetSmall()
                }
            } // HStack Budget/Daily
            } //VSTACK Daily/Text/Arrow
            
            HStack{
            RoundedRectangle(cornerRadius: 20)
                .frame(width: 263, height: 58)
                .overlay(
                Text("Today notes")
                    .foregroundColor(.white)
                    .font(.custom("Inter-Thin", size: 40)))
                Spacer().frame(width: 160)
                } // HStack
            
            Notes()
            
            HStack{
                Image(systemName: "arrow.left")
                Spacer()
                Image(systemName: "arrow.right")
                } //HStack
            
        }// VStack
    }
    var formattedDate: String {
           let dateFormatter = DateFormatter()
           dateFormatter.dateFormat = "dd/MM/yy"
           return dateFormatter.string(from: currentDate)
       }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
