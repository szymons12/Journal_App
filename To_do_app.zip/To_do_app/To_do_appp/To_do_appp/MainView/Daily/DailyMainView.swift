//
//  SwiftUIView.swift
//  To_do_appp
//
//  Created by szymon on 07/03/2024.
//

import SwiftUI

struct DailyMainView: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .frame(width: 220, height: 220)
            .foregroundColor(Color("bdgBack"))
            .overlay(
                ZStack{
                    
                        HStack{
                        List{
                            ForEach(1..<15) { index in
                                HStack {
                                    Image(systemName: "circle")
                                        .frame(width: 20, height: 20)
                                        .foregroundColor(.white)
                                    Text("bulka")
                                        .font(.custom("Inter-Thin", size: 16))
                                        .foregroundColor(.white)
                                }//HStack
                                .listRowSeparator(.hidden)
                                .listRowBackground(Color("bdgBack"))
                                
                            }
                            
                            
                        }
                        
                        .listStyle(PlainListStyle())
                        .cornerRadius(20)
                        
                            
                       
                            VStack{
                                Spacer()
                                    .frame(width: 40,height: 180)
                            HStack() {
                            Button(action: {
                                
                            }, label: {
                               
                                        Image(systemName: "plus")
                                    .font(.system(size: 40, weight: .thin))
                                        .foregroundColor(.white)
                                        
                                    
                            })
                                Spacer()
                                
                        }// Hstack
                        .frame(width:37, height: 33)
                                Spacer()
                        }
                    }
                }
                
            ) // Overlay

    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        DailyMainView()
    }
}
