//
//  To_do_apppApp.swift
//  To_do_appp
//
//  Created by szymon on 18/01/2024.
//

import SwiftUI

@main
struct To_do_apppApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
