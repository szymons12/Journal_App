//
//  ContentView.swift
//  To_do_appp
//
//  Created by szymon on 18/01/2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       
        List(0..<20)  { item in
                HStack {
                    Text("no name")
                        .font(.custom("Inter-Thin", size: 32))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 20)

                    Text("$")
                        .font(.custom("Inter-Thin", size: 32))
                        .foregroundColor(.black)
                        .padding(.trailing, 40)
                }//HStack
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
