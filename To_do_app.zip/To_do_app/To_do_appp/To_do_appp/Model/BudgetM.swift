//
//  Budget.swift
//  To_do_appp
//
//  Created by szymon on 25/02/2024.
//

import Foundation
import CoreData

class CoreDataViewModel: ObservableObject {
    
    let container: NSPersistentContainer
    @Published var savedEntities: [TaskEntity] = []
    
    init(){
        container = NSPersistentContainer(name: "TaskContainer")
        container.loadPersistentStores{ (description, error) in
            if let error = error {
                print("Error loading core data. \(error)")}
        }
        fetchTask()
    }
    func fetchTask(){
        let request = NSFetchRequest<TaskEntity>(entityName: "TaskEntity")
        
        do{
            savedEntities = try container.viewContext.fetch(request)
        } catch let error{
            print("Error fetching. \(error)")
        }
    } // fetchTask
    
    func addTask(text: String, int: Int16){
        let newTask = TaskEntity(context: container.viewContext)
        newTask.name = text
        newTask.cost = int
        saveData()
    } // addTask
    
    func deleteTask(indexSet: IndexSet){
        guard let index = indexSet.first else {return}
        let entity = savedEntities[index]
        container.viewContext.delete(entity)
        saveData()
    } // deleteTask
    
    func saveData(){
        do{
            try container.viewContext.save()
            fetchTask()
        } catch let error{
            print("Error saving \(error)")}
    } // saveData
    
} // class
